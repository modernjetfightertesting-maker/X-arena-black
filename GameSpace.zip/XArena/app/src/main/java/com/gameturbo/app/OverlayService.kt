package com.gameturbo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.math.abs

/**
 * Floating window: garis abu-abu di tepi layar. Ketuk / geser ke dalam -> panel X Arena
 * (halaman panel.html) meluncur keluar dari tepi. Garis hanya muncul di atas game.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { Games.prefs(this) }

    private var handle: FrameLayout? = null
    private var line: View? = null
    private lateinit var lpHandle: WindowManager.LayoutParams
    private var panel: WebView? = null
    private var warm: WebView? = null
    private var warmKey = ""
    private var lpPanel: WindowManager.LayoutParams? = null
    private var mini: TextView? = null
    private var intro: View? = null
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null
    private var lastIntro = 0L
    private var lastGame: String? = null
    private var previewIntro = false
    private var lpMini: WindowManager.LayoutParams? = null

    private var gamePkg: String? = null
    private var gameSet: Set<String> = emptySet()
    private var gameSetAt = 0L
    private var rightSide = true
    private var pmode = "bal"
    private var lineMode = ""
    private var keepOn = false
    private var dndOn = false
    private var prevFilter = -1
    private var lastAuto = 0L
    private var cross: View? = null
    private var xDndSet = false

    @Volatile
    private var fps = 0
    private var frames = 0
    private var lastMs = 0L
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val now = frameTimeNanos / 1_000_000L
            if (lastMs == 0L) lastMs = now
            frames++
            val dt = now - lastMs
            if (dt >= 1000L) {
                fps = (frames * 1000L / dt).toInt()
                frames = 0
                lastMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            detectForeground()
            updateMini()
            pmode = prefs.getString("pmode", pmode) ?: pmode
            val keepWant = prefs.getBoolean("keepmanual", false) || pmode == "gt"
            if (keepWant != keepOn) { keepOn = keepWant; applyKeepOn() }
            if (pmode != lineMode) { lineMode = pmode; line?.background = lineDrawable() }
            if (warm != null && warmKey != panelKey(false)) { dropWarm(); prewarm() }
            if (prefs.getBoolean("gs_dnd", false) && gamePkg != null && !xDndSet) {
                xDndSet = true; setDnd(true)
            }
            val nowMs = System.currentTimeMillis()
            if (pmode == "gt" && gamePkg != null && nowMs - lastAuto > 180_000L) {
                lastAuto = nowMs
                Thread { Booster.boost(this@OverlayService, setOfNotNull(gamePkg)) }.start()
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        rightSide = prefs.getString("side", "right") == "right"
        pmode = prefs.getString("pmode", "bal") ?: "bal"
        keepOn = pmode == "gt"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_MINI -> {
                toggleMini()
                return START_STICKY
            }
            ACTION_INTRO -> previewIntro = true
        }
        val launched = intent?.getStringExtra(EXTRA_GAME)
        if (launched != null) gamePkg = launched
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val want = prefs.getString("side", "right") == "right"
        if (handle != null && want != rightSide) {
            rightSide = want
            handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            handle = null
        }
        if (handle == null) {
            buildHandle()
            handler.postDelayed({ prewarm() }, 1500L)
            handler.removeCallbacks(tick)
            handler.post(tick)
        }
        if (previewIntro) {
            previewIntro = false
            lastIntro = 0L
            showIntro()
        } else if (launched != null) {
            handler.postDelayed({ showIntro() }, 1500L)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        removePanel()
        dropWarm()
        removeMini()
        removeIntro()
        removeCross()
        removeEclipse()
        stopMacro()
        try { wifiLock?.release() } catch (_: Exception) {}
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
        if (dndOn) setDnd(false)
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseFlags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (keepOn) f = f or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        return f
    }

    private fun sideGravity(): Int = Gravity.TOP or (if (rightSide) Gravity.END else Gravity.START)

    private fun toast(s: String) = Toast.makeText(applicationContext, s, Toast.LENGTH_SHORT).show()

    private fun openActivity(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Tidak bisa dibuka dari sini")
        }
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun startAsForeground() {
        val channelId = "turbo"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "X Arena", NotificationManager.IMPORTANCE_LOW)
            nm().createNotificationChannel(ch)
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("X Arena aktif")
            .setContentText("Garis panel ada di tepi layar saat main game")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Matikan", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- garis di tepi layar ----------

    private fun lineParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(
        dp(4), dp(120), Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START)
    )

    private fun lineDrawable(): GradientDrawable {
        val r = dp(3).toFloat()
        return GradientDrawable().apply {
            setColor(Color.parseColor("#99C9CCD2"))
            cornerRadii = if (rightSide) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        }
    }

    private fun buildHandle() {
        val box = FrameLayout(this)
        val l = View(this)
        l.background = lineDrawable()
        box.addView(l, lineParams())
        line = l

        lpHandle = WindowManager.LayoutParams(
            dp(24), dp(132), overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        ).apply {
            gravity = sideGravity()
            x = 0
            y = prefs.getInt("hy", dp(120))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        var opened = false
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lpHandle.y
                    dragging = false; opened = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val inward = if (rightSide) -dx else dx
                    if (!opened && !dragging && inward > dp(16) && abs(dx) > abs(dy)) {
                        opened = true
                        expand()
                    } else if (!opened && (dragging || (abs(dy) > slop && abs(dy) > abs(dx)))) {
                        dragging = true
                        val maxY = (Sys.realSize(this).second - dp(132)).coerceAtLeast(0)
                        lpHandle.y = (startY + dy).toInt().coerceIn(0, maxY)
                        try { wm.updateViewLayout(box, lpHandle) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (opened) {
                        // sudah dibuka lewat geseran
                    } else if (dragging) {
                        prefs.edit().putInt("hy", lpHandle.y).apply()
                    } else {
                        expand()
                    }
                }
            }
            true
        }
        handle = box
        wm.addView(box, lpHandle)
    }

    private fun applyKeepOn() {
        try {
            handle?.let { lpHandle.flags = baseFlags(); wm.updateViewLayout(it, lpHandle) }
            val p = panel
            val lp = lpPanel
            if (p != null && lp != null) { lp.flags = baseFlags(); wm.updateViewLayout(p, lp) }
            val m = mini
            val lm = lpMini
            if (m != null && lm != null) { lm.flags = baseFlags(); wm.updateViewLayout(m, lm) }
        } catch (_: Exception) {}
    }

    // ---------- deteksi game di depan ----------

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return m == android.app.AppOpsManager.MODE_ALLOWED
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15000L, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = e.packageName
        }
        return last
    }

    private fun showOverlays(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        val h = handle
        if (h != null && panel == null && h.visibility != v) h.visibility = v
        val m = mini
        if (m != null && m.visibility != v) m.visibility = v
    }

    private fun detectForeground() {
        if (!prefs.getBoolean("auto", true) || !hasUsage()) {
            showOverlays(true)
            return
        }
        val fg = foregroundPkg() ?: return
        val nowMs = System.currentTimeMillis()
        if (nowMs - gameSetAt > 30000L) {
            gameSet = Games.gamePackages(this); gameSetAt = nowMs
        }
        if (fg in gameSet) {
            gamePkg = fg
            showOverlays(true)
            if (fg != lastGame) {
                lastGame = fg
                showIntro()
            }
        } else {
            lastGame = null
            if (xDndSet) { xDndSet = false; setDnd(false) }
            if (panel != null) collapse()
            showOverlays(false)
        }
    }

    // ---------- panel (WebView) ----------

    private fun updateFrameCb() {
        Choreographer.getInstance().removeFrameCallback(frameCb)
        if (panel != null || mini != null) {
            lastMs = 0L; frames = 0
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
    }

    private fun panelKey(xm: Boolean): String = if (xm) "x" else "n" + (if (rightSide) "r" else "l")

    private fun makePanelView(xm: Boolean): WebView {
        val w = WebView(applicationContext)
        w.setBackgroundColor(Color.TRANSPARENT)
        if (Build.VERSION.SDK_INT >= 29) w.isForceDarkAllowed = false
        w.background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= 29) w.settings.forceDark = android.webkit.WebSettings.FORCE_DARK_OFF
        w.alpha = 0f
        w.webViewClient = object : android.webkit.WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) { view?.postDelayed({ view.alpha = 1f }, 60L) }
        }
        w.overScrollMode = View.OVER_SCROLL_NEVER
        w.isVerticalScrollBarEnabled = false
        w.isHorizontalScrollBarEnabled = false
        w.settings.javaScriptEnabled = true
        w.addJavascriptInterface(PanelBridge(), "AP")
        w.loadUrl(if (xm) "file:///android_asset/panelx.html" else "file:///android_asset/panel.html?side=" + (if (rightSide) "r" else "l"))
        return w
    }

    /** Muat halaman panel di latar belakang supaya saat digeser langsung muncul. */
    private fun prewarm() {
        if (warm != null || panel != null || !running) return
        if (!Settings.canDrawOverlays(this)) return
        try {
            val xm = false
            warm = makePanelView(xm)
            warmKey = panelKey(xm)
        } catch (_: Throwable) {
            warm = null
        }
    }

    private fun dropWarm() {
        val w = warm ?: return
        warm = null
        try { w.destroy() } catch (_: Throwable) {}
    }

    private fun expand() {
        if (panel != null) return
        val xm = false
        val key = panelKey(xm)
        val ready = warm != null && warmKey == key
        val w: WebView
        if (ready) {
            w = warm!!
            warm = null
        } else {
            dropWarm()
            w = makePanelView(xm)
        }
        val sz = Sys.realSize(this)
        val sh = if (sz.first < sz.second) sz.first else sz.second
        val sw = if (sz.first < sz.second) sz.second else sz.first
        val panelH = (sh * 0.92f).toInt()
        val winW = if (xm) sw else (panelH * 1.12f).toInt() + dp(18)
        val lp = WindowManager.LayoutParams(
            winW, (panelH + dp(16)).coerceAtMost(sh),
            overlayType(),
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (xm) Gravity.TOP or Gravity.START else Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START)
        lp.x = 0
        lp.y = 0
        w.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) collapse()
            false
        }
        try {
            wm.addView(w, lp)
        } catch (e: Exception) {
            w.destroy()
            toast("Panel gagal dibuka")
            return
        }
        panel = w
        lpPanel = lp
        handle?.visibility = View.GONE
        w.evaluateJavascript("window.rbOpen&&window.rbOpen()", null)
        updateFrameCb()
    }

    private fun collapse() {
        val p = panel ?: return
        p.evaluateJavascript("window.rbClose&&window.rbClose()", null)
        handler.postDelayed({ removePanel() }, 240L)
    }

    private fun removePanel() {
        val p = panel ?: return
        panel = null
        lpPanel = null
        try { wm.removeView(p) } catch (_: Exception) {}
        try { p.destroy() } catch (_: Exception) {}
        handle?.visibility = View.VISIBLE
        updateFrameCb()
        handler.postDelayed({ prewarm() }, 400L)
    }

    // ---------- mini intro (kartu kecil saat masuk game) ----------

    private fun modeColor(m: String = pmode): Int = when (m) {
        "gt" -> Color.parseColor("#FFA21F")
        "low" -> Color.parseColor("#4CE08A")
        else -> Color.parseColor("#2FA8FF")
    }

    /** Kartu mini X Arena di pojok kiri atas saat game dibuka: cincin tick menyapu, teks mode muncul. */
    private inner class IntroView(ctx: android.content.Context, val acc: Int, val wild: Boolean, val md: String = "bal") : View(ctx) {
        var t = 0f
        private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private fun cl(x: Float) = x.coerceIn(0f, 1f)
        private fun eo(x: Float): Float { val k = 1 - cl(x); return 1 - k * k * k }
        private fun eio(x: Float): Float { val k = cl(x); return k * k * (3 - 2 * k) }
        private fun a(c: Int, al: Float) = Color.argb((al.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

        private fun icon(c: android.graphics.Canvas, k: Int, cx: Float, cy: Float, s: Float, col: Int, bg: Int) {
            p.strokeCap = android.graphics.Paint.Cap.ROUND; p.strokeJoin = android.graphics.Paint.Join.ROUND
            p.color = col; p.strokeWidth = s * 0.17f
            when (k) {
                0 -> {
                    p.style = android.graphics.Paint.Style.STROKE
                    c.drawRoundRect(cx - s * 0.5f, cy - s * 0.5f, cx + s * 0.5f, cy + s * 0.5f, s * 0.14f, s * 0.14f, p)
                    p.style = android.graphics.Paint.Style.FILL
                    c.drawRect(cx - s * 0.2f, cy - s * 0.2f, cx + s * 0.2f, cy + s * 0.2f, p)
                }
                1 -> {
                    p.style = android.graphics.Paint.Style.FILL
                    val path = android.graphics.Path()
                    for (i in 0 until 6) {
                        val ang = Math.toRadians(30.0 + 60.0 * i)
                        val x = cx + (Math.cos(ang) * s * 0.58).toFloat(); val y = cy + (Math.sin(ang) * s * 0.58).toFloat()
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close(); c.drawPath(path, p)
                    p.color = bg; c.drawCircle(cx, cy, s * 0.17f, p)
                }
                2 -> {
                    p.style = android.graphics.Paint.Style.STROKE
                    val r = android.graphics.RectF(cx - s * 0.45f, cy - s * 0.5f, cx + s * 0.45f, cy + s * 0.4f)
                    c.drawArc(r, 160f, 220f, false, p)
                    c.drawLine(cx - s * 0.45f, cy + s * 0.4f, cx + s * 0.45f, cy + s * 0.4f, p)
                    c.drawLine(cx - s * 0.55f, cy - s * 0.55f, cx + s * 0.55f, cy + s * 0.55f, p)
                }
                else -> {
                    p.style = android.graphics.Paint.Style.STROKE
                    c.drawLine(cx - s * 0.5f, cy + s * 0.5f, cx + s * 0.12f, cy - s * 0.12f, p)
                    p.style = android.graphics.Paint.Style.FILL
                    val st = android.graphics.Path(); val sx = cx + s * 0.28f; val sy = cy - s * 0.28f; val q = s * 0.34f
                    st.moveTo(sx, sy - q); st.lineTo(sx + q * 0.25f, sy - q * 0.25f); st.lineTo(sx + q, sy); st.lineTo(sx + q * 0.25f, sy + q * 0.25f)
                    st.lineTo(sx, sy + q); st.lineTo(sx - q * 0.25f, sy + q * 0.25f); st.lineTo(sx - q, sy); st.lineTo(sx - q * 0.25f, sy - q * 0.25f); st.close()
                    c.drawPath(st, p)
                    c.drawCircle(cx - s * 0.3f, cy - s * 0.4f, s * 0.07f, p)
                }
            }
        }

        override fun onDraw(c: android.graphics.Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val out = eio((t - 3.45f) / 0.45f)
            val fade = cl(t / 0.3f) * (1f - out)
            val slide = (1f - eo(t / 0.45f)) * -w * 0.25f - out * w * 0.15f
            c.save(); c.translate(slide, 0f)
            p.style = android.graphics.Paint.Style.FILL
            p.shader = null
            val bgc = Color.argb((fade * 240).toInt(), 8, 11, 18)
            p.color = bgc
            val rr = h * 0.07f
            c.drawRoundRect(0f, 0f, w, h, rr, rr, p)
            p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h, intArrayOf(Color.argb((fade * 40).toInt(), 255, 255, 255), Color.TRANSPARENT), null, android.graphics.Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, w, h * 0.5f, rr, rr, p)
            p.shader = null
            // wordmark: angular italic letters drawn as paths, chrome + orange X
            val wm0 = eo((t - 0.1f) / 0.5f)
            val uu = minOf(h * 0.115f, w * 0.8f / 8.1f)
            val gx = (w - uu * 7.85f) / 2f + uu * 0.12f
            val gy = h * 0.2f
            val lt = arrayOf(
                arrayOf(floatArrayOf(0f, 0f, .8f, 1f), floatArrayOf(.8f, 0f, 0f, 1f)),
                arrayOf(floatArrayOf(0f, 1f, .4f, 0f, .8f, 1f), floatArrayOf(.17f, .66f, .63f, .66f)),
                arrayOf(floatArrayOf(0f, 1f, 0f, 0f, .6f, 0f, .8f, .2f, .8f, .38f, .6f, .56f, 0f, .56f), floatArrayOf(.4f, .56f, .8f, 1f)),
                arrayOf(floatArrayOf(.8f, 0f, 0f, 0f, 0f, 1f, .8f, 1f), floatArrayOf(0f, .5f, .62f, .5f)),
                arrayOf(floatArrayOf(0f, 1f, 0f, 0f, .8f, 1f, .8f, 0f)))
            val order = intArrayOf(0, 1, 2, 3, 4, 1)
            val xs = floatArrayOf(0f, 1.55f, 2.85f, 4.15f, 5.45f, 6.75f)
            c.save(); c.translate(gx, gy); c.skew(-0.3f, 0f)
            p.style = android.graphics.Paint.Style.STROKE
            p.strokeJoin = android.graphics.Paint.Join.MITER; p.strokeMiter = 1.8f; p.strokeCap = android.graphics.Paint.Cap.BUTT
            for (pass in 0 until 2) {
                for (li in 0 until 6) {
                    val dx = xs[li] * uu
                    val pth = android.graphics.Path()
                    for (ln in lt[order[li]]) {
                        var i = 0
                        while (i < ln.size) {
                            val px = dx + ln[i] * uu * 1.375f; val py = (ln[i + 1] - 1f) * uu
                            if (i == 0) pth.moveTo(px, py) else pth.lineTo(px, py)
                            i += 2
                        }
                    }
                    if (pass == 0) {
                        p.shader = null; p.strokeWidth = uu * 0.42f; p.color = Color.argb((fade * 255 * wm0).toInt(), 6, 8, 12)
                    } else {
                        p.strokeWidth = uu * 0.31f
                        val top = Color.argb((fade * 255 * wm0).toInt(), if (li == 0) 255 else 250, if (li == 0) 214 else 250, if (li == 0) 90 else 252)
                        val mid = Color.argb((fade * 255 * wm0).toInt(), if (li == 0) 255 else 200, if (li == 0) 150 else 204, if (li == 0) 20 else 212)
                        val bot = Color.argb((fade * 255 * wm0).toInt(), if (li == 0) 220 else 120, if (li == 0) 90 else 126, if (li == 0) 10 else 140)
                        p.shader = android.graphics.LinearGradient(0f, -uu, 0f, 0f, intArrayOf(top, mid, mid, bot), floatArrayOf(0f, .48f, .5f, 1f), android.graphics.Shader.TileMode.CLAMP)
                    }
                    c.drawPath(pth, p)
                }
            }
            p.shader = null
            c.restore()
            p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat() * 0.8f
            p.color = a(Color.WHITE, 0.35f * fade * wm0)
            val sw = android.graphics.Path(); sw.moveTo(w * 0.12f, h * 0.275f); sw.lineTo(w * 0.52f, h * 0.275f); sw.lineTo(w * 0.57f, h * 0.255f); sw.lineTo(w * 0.9f, h * 0.255f)
            c.drawPath(sw, p)
            val names = arrayOf(
                when (md) { "gt" -> "Performance Mode"; "low" -> "Power Saving Mode"; else -> "Balanced Mode" },
                "Quick Access Tools", "Call reject", "Game Assistant")
            p.style = android.graphics.Paint.Style.FILL
            p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            p.textAlign = android.graphics.Paint.Align.LEFT
            p.textSize = h * 0.067f
            for (i in 0 until 4) {
                val rv = eio((t - 0.5f - i * 0.18f) / 0.4f)
                if (rv <= 0f) continue
                val cy = h * (0.455f + 0.157f * i)
                val al = fade * rv
                val ox = (1f - rv) * w * 0.06f
                icon(c, i, w * 0.157f + ox, cy, h * 0.052f, a(acc, al), bgc)
                p.color = a(Color.rgb(240, 242, 246), al)
                var tx = w * 0.295f + ox
                val mw = w * 0.68f
                var nm = names[i]
                while (p.measureText(nm) > mw && nm.length > 4) nm = nm.dropLast(1)
                if (nm != names[i]) nm = nm.dropLast(1) + "..."
                c.drawText(nm, tx, cy + h * 0.024f, p)
            }
            p.textAlign = android.graphics.Paint.Align.LEFT
            c.restore()
        }
    }

    private fun showIntro() {
        if (!prefs.getBoolean("intro", true)) return
        val now = System.currentTimeMillis()
        if (now - lastIntro < 10_000L || intro != null) return
        if (!Settings.canDrawOverlays(this)) return
        lastIntro = now
        val sz = Sys.realSize(this)
        val sh = if (sz.first < sz.second) sz.first else sz.second
        val v = IntroView(this, modeColor(), pmode == "gt", pmode)
        val w = minOf(dp(190), (sh * 0.62f).toInt())
        val lp = WindowManager.LayoutParams(w, (w * 0.98f).toInt(), overlayType(), baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(14)
        lp.y = dp(14)
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            return
        }
        intro = v
        val an = android.animation.ValueAnimator.ofFloat(0f, 4.1f)
        an.duration = 4100L
        an.interpolator = android.view.animation.LinearInterpolator()
        an.addUpdateListener { v.t = it.animatedValue as Float; v.invalidate() }
        an.start()
        handler.postDelayed({ removeIntro() }, 4200L)
    }

    private fun removeIntro() {
        val w = intro ?: return
        intro = null
        try { wm.removeView(w) } catch (_: Exception) {}
    }

    // ---------- mini monitor (WM) ----------

    private fun toggleMini() {
        if (mini != null) {
            removeMini()
            return
        }
        val tv = TextView(this)
        tv.textSize = 11f
        tv.setTextColor(Color.WHITE)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(10), dp(5), dp(10), dp(5))
        tv.background = GradientDrawable().apply {
            setColor(Color.parseColor("#CC0A0A0E"))
            cornerRadius = dp(10).toFloat()
            setStroke(dp(1), (modeColor() and 0xFFFFFF) or (0x99 shl 24))
        }
        tv.text = "X Arena"
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), baseFlags(), PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(16)
        lp.y = dp(10)
        var dx = 0f
        var dy = 0f
        var sx = 0
        var sy = 0
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + (e.rawX - dx)).toInt().coerceAtLeast(0)
                    lp.y = (sy + (e.rawY - dy)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                }
            }
            true
        }
        try {
            wm.addView(tv, lp)
        } catch (e: Exception) {
            return
        }
        mini = tv
        lpMini = lp
        updateFrameCb()
    }

    private fun removeMini() {
        val m = mini ?: return
        mini = null
        lpMini = null
        try { wm.removeView(m) } catch (_: Exception) {}
        updateFrameCb()
    }

    private fun updateMini() {
        val m = mini ?: return
        val cpu = Sys.cpuPct()
        val sb = StringBuilder("FPS ").append(fps)
        if (cpu >= 0) sb.append("  CPU ").append(cpu).append("%")
        sb.append("  RAM ").append(Booster.ramPercent(this)).append("%")
        Booster.batteryTempC(this)?.let { sb.append("  ").append(it.toInt()).append("°C") }
        m.text = sb.toString()
    }

    // ---------- crosshair ----------

    private fun showCross() {
        if (cross != null) return
        val v = object : View(this) {
            override fun onDraw(c: android.graphics.Canvas) {
                val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                val col = try { Color.parseColor(prefs.getString("cx_color", "#FF2A3A")) } catch (_: Exception) { Color.RED }
                p.color = col
                p.alpha = (prefs.getInt("cx_alpha", 100) * 255 / 100).coerceIn(30, 255)
                val sz = prefs.getInt("cx_size", 50).coerceIn(10, 100)
                val l = dp(4) + dp(22) * sz / 100f
                val g = dp(3).toFloat()
                p.strokeWidth = dp(2).toFloat()
                p.strokeCap = android.graphics.Paint.Cap.ROUND
                val cx = width / 2f
                val cy = height / 2f
                when (prefs.getInt("cx_shape", 0)) {
                    1 -> { p.style = android.graphics.Paint.Style.FILL; c.drawCircle(cx, cy, dp(2) + l / 6f, p) }
                    2 -> { p.style = android.graphics.Paint.Style.STROKE; c.drawCircle(cx, cy, l * 0.7f, p)
                        p.style = android.graphics.Paint.Style.FILL; c.drawCircle(cx, cy, dp(1) + 0.5f, p) }
                    3 -> { c.drawLine(cx - l, cy, cx + l, cy, p); c.drawLine(cx, cy - l, cx, cy + l, p)
                        p.style = android.graphics.Paint.Style.FILL; c.drawCircle(cx, cy, dp(2).toFloat(), p) }
                    4 -> { val d = l * 0.75f
                        c.drawLine(cx - d, cy - d, cx - g, cy - g, p); c.drawLine(cx + d, cy + d, cx + g, cy + g, p)
                        c.drawLine(cx - d, cy + d, cx - g, cy + g, p); c.drawLine(cx + d, cy - d, cx + g, cy - g, p) }
                    else -> { c.drawLine(cx - g - l, cy, cx - g, cy, p); c.drawLine(cx + g, cy, cx + g + l, cy, p)
                        c.drawLine(cx, cy - g - l, cx, cy - g, p); c.drawLine(cx, cy + g, cx, cy + g + l, p)
                        p.style = android.graphics.Paint.Style.FILL; c.drawCircle(cx, cy, dp(1) + 0.5f, p) }
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(90), dp(90), overlayType(),
            baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        try {
            wm.addView(v, lp)
            cross = v
        } catch (_: Exception) {
        }
    }

    // ---------- Eclipse Touch: blokir sentuhan tepi layar ----------
    private var eclipse: View? = null

    private fun showEclipse() {
        if (eclipse != null) return
        val v = View(this)
        v.setOnTouchListener { _, _ -> true }
        val lp = WindowManager.LayoutParams(
            dp(20), WindowManager.LayoutParams.MATCH_PARENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (rightSide) Gravity.START else Gravity.END)
        try { wm.addView(v, lp); eclipse = v } catch (_: Exception) {}
    }

    private fun removeEclipse() {
        val v = eclipse ?: return
        eclipse = null
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ---------- Macro: auto tap ----------
    private var tapView: View? = null
    private var tapLp: WindowManager.LayoutParams? = null
    private var tapState = 0 // 0 mati, 1 atur posisi, 2 jalan
    private val tapRun = object : Runnable {
        override fun run() {
            if (tapState != 2) return
            val lp = tapLp
            val sv = RbAccessibilityService.inst
            if (lp != null && sv != null) sv.tap((lp.x + dp(22)).toFloat(), (lp.y + dp(22)).toFloat())
            handler.postDelayed(this, prefs.getInt("tap_ms", 100).toLong().coerceAtLeast(30L))
        }
    }

    private fun macroNext(): String {
        if (tapState == 0) {
            if (RbAccessibilityService.inst == null) {
                handler.post { collapse(); openActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                return "!Aktifkan layanan aksesibilitas X Arena dulu"
            }
            val v = object : View(this) {
                override fun onDraw(c: android.graphics.Canvas) {
                    val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    p.color = Color.parseColor(if (tapState == 2) "#66FF4A22" else "#66FFFFFF")
                    c.drawCircle(width / 2f, height / 2f, width / 2f - 2f, p)
                    p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 4f
                    p.color = Color.parseColor(if (tapState == 2) "#FF4A22" else "#FFFFFF")
                    c.drawCircle(width / 2f, height / 2f, width / 2f - 3f, p)
                }
            }
            val lp = WindowManager.LayoutParams(
                dp(44), dp(44), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = prefs.getInt("tap_x", dp(200)); lp.y = prefs.getInt("tap_y", dp(200))
            var dx = 0f; var dy = 0f; var ox = 0; var oy = 0
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - dx).toInt(); lp.y = oy + (e.rawY - dy).toInt(); try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
                    MotionEvent.ACTION_UP -> prefs.edit().putInt("tap_x", lp.x).putInt("tap_y", lp.y).apply()
                }
                true
            }
            try { wm.addView(v, lp) } catch (_: Exception) { return "!Gagal menampilkan target" }
            tapView = v; tapLp = lp; tapState = 1
            handler.post { collapse() }
            return "Geser lingkaran ke tombol yang mau diketuk, lalu buka panel dan tekan Macro lagi untuk mulai"
        }
        val v = tapView
        val lp = tapLp
        if (tapState == 1 && v != null && lp != null) {
            tapState = 2
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            v.invalidate()
            handler.post { collapse() }
            handler.post(tapRun)
            return "Macro berjalan. Buka panel dan tekan Macro untuk berhenti"
        }
        stopMacro()
        return "Macro berhenti"
    }

    private fun stopMacro() {
        tapState = 0
        handler.removeCallbacks(tapRun)
        val v = tapView ?: return
        tapView = null
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun removeCross() {
        val v = cross ?: return
        cross = null
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ---------- aksi panel ----------

    private fun setDnd(on: Boolean) {
        val n = nm()
        if (!n.isNotificationPolicyAccessGranted) return
        if (on) {
            if (prevFilter == -1) prevFilter = n.currentInterruptionFilter
            n.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else if (prevFilter >= 1) {
            n.setInterruptionFilter(prevFilter); prevFilter = -1
        }
        dndOn = on
    }

    private fun setPMode(m: String) {
        pmode = m
        prefs.edit().putString("pmode", m).apply()
        keepOn = m == "gt"
        applyKeepOn()
        lastAuto = System.currentTimeMillis()
        if (m == "gt") Thread { Booster.boost(this, setOfNotNull(gamePkg)) }.start()
    }

    private fun togglePref(key: String, label: String): String {
        val v = !prefs.getBoolean(key, false)
        prefs.edit().putBoolean(key, v).apply()
        return label + (if (v) " aktif" else " mati") + " (tersimpan sebagai preferensi)"
    }

    private fun stateJson(): String {
        val t = Booster.batteryTempC(this)
        return JSONObject()
            .put("cpu", Sys.cpuPct())
            .put("gpu", Sys.gpuPct())
            .put("fps", fps)
            .put("ram", Booster.ramPercent(this))
            .put("temp", if (t != null) t.toDouble() else -1.0)
            .put("bat", Booster.batteryPercent(this))
            .put("mode", pmode)
            .put("dnd", dndOn)
            .put("eclipse", prefs.getBoolean("rb_eclipse", false))
            .put("bypass", prefs.getBoolean("rb_bypass", false))
            .put("rec", RecorderService.recording)
            .put("mini", mini != null)
            .put("cpuGhz", Sys.cpuGhz())
            .put("gpuMhz", Sys.gpuMhz())
            .put("cross", cross != null)
            .put("keep", prefs.getBoolean("keepmanual", false))
            .put("autolight", Sys.autoLight(this))
            .put("cool", prefs.getBoolean("cool_on", false))
            .put("bright", Sys.brightPct(this) * 255 / 100)
            .put("vol", Sys.volPct(this))
            .put("refresh", Sys.refreshMode(this))
            .put("wifi", wifiLock?.isHeld == true)
            .put("pf", JSONObject().also { o -> for ((kk, vv) in prefs.all) { if (kk.startsWith("pf_") && vv is Boolean) o.put(kk, vv) } })
            .put("cxShape", prefs.getInt("cx_shape", 0))
            .put("cxColor", prefs.getString("cx_color", "#FF2A3A"))
            .put("cxSize", prefs.getInt("cx_size", 50))
            .put("cxAlpha", prefs.getInt("cx_alpha", 100))
            .put("tapMs", prefs.getInt("tap_ms", 100))
            .put("macro", tapState)
            .put("x", prefs.getBoolean("xmode", false))
            .toString()
    }

    private fun doShot() {
        collapse()
        handler.postDelayed({
            val svc = RbAccessibilityService.inst
            if (svc == null) {
                toast("Aktifkan layanan aksesibilitas X Arena dulu")
                openActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                svc.shoot { ok -> toast(if (ok) "Screenshot tersimpan di Galeri (Pictures/XArena)" else "Screenshot gagal") }
            }
        }, 700L)
    }

    inner class PanelBridge {
        @JavascriptInterface
        fun state(): String = stateJson()

        @JavascriptInterface
        fun shortcuts(): String {
            val arr = org.json.JSONArray()
            try {
                val pm = packageManager
                val list = ArrayList<String>()
                prefs.getString("last_games", "")?.split(",")?.filter { it.isNotEmpty() }?.let { list.addAll(it) }
                for (pkg in Games.gamePackages(this@OverlayService)) if (pkg !in list) list.add(pkg)
                for (pkg in list.take(5)) {
                    if (pm.getLaunchIntentForPackage(pkg) == null) continue
                    val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    arr.put(JSONObject().put("p", pkg).put("n", label).put("i", Games.iconB64(pm.getApplicationIcon(pkg))))
                }
            } catch (_: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun dock(): String {
            val arr = org.json.JSONArray()
            try {
                val pm = packageManager
                val saved = prefs.getString("dock_pkgs", null)
                val list: List<String> = if (saved == null) {
                    val l = ArrayList<String>()
                    prefs.getString("last_games", "")?.split(",")?.filter { it.isNotEmpty() }?.let { l.addAll(it) }
                    for (pkg in Games.gamePackages(this@OverlayService)) if (pkg !in l) l.add(pkg)
                    l
                } else saved.split(",").filter { it.isNotEmpty() }
                for (pkg in list.take(8)) {
                    if (pm.getLaunchIntentForPackage(pkg) == null) continue
                    val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                    arr.put(JSONObject().put("p", pkg).put("n", label).put("i", Games.iconB64(pm.getApplicationIcon(pkg))))
                }
            } catch (_: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun allApps(): String {
            val arr = org.json.JSONArray()
            val cur = dockList().toSet()
            Games.launchable(this@OverlayService).forEach { (p, n) ->
                arr.put(JSONObject().put("p", p).put("n", n).put("s", p in cur))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun appIcon(pkg: String): String = try {
            Games.iconB64(packageManager.getApplicationIcon(pkg))
        } catch (_: Exception) { "" }

        @JavascriptInterface
        fun setDock(csv: String) {
            prefs.edit().putString("dock_pkgs", csv).apply()
        }

        private fun dockList(): List<String> {
            val saved = prefs.getString("dock_pkgs", null)
            if (saved != null) return saved.split(",").filter { it.isNotEmpty() }
            val l = ArrayList<String>()
            prefs.getString("last_games", "")?.split(",")?.filter { it.isNotEmpty() }?.let { l.addAll(it) }
            for (pkg in Games.gamePackages(this@OverlayService)) if (pkg !in l) l.add(pkg)
            return l.take(8)
        }

        @JavascriptInterface
        fun open(pkg: String) {
            handler.post {
                collapse()
                val i = packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) openActivity(i)
            }
        }

        @JavascriptInterface
        fun act(name: String, arg: String): String {
            return try {
                actInner(name, arg)
            } catch (e: Throwable) {
                "!Aksi gagal: " + (e.message ?: name)
            }
        }

        private fun actInner(name: String, arg: String): String {
            if (name.startsWith("pf_")) {
                val v = !prefs.getBoolean(name, false)
                prefs.edit().putBoolean(name, v).apply()
                return if (name == "pf_gfx") (if (v) "Graphic Enhancement On" else "Graphic Enhancement disabled")
                else if (name == "pf_esport") (if (v) "Esports-grade control enabled. Device temperature may increase." else "Esports-grade control disabled")
                else arg + (if (v) " On" else " Off")
            }
            when (name) {
                "mode" -> {
                    handler.post { setPMode(arg) }
                    return when (arg) {
                        "gt" -> "Performance mode enabled. Device temperature may increase."
                        "low" -> "When this mode is enabled, device performance will be reduced."
                        else -> "Balanced mode enabled."
                    }
                }
                "boost" -> {
                    val n = Booster.boost(this@OverlayService, setOfNotNull(gamePkg))
                    return "Menutup $n app di background"
                }
                "dnd" -> {
                    if (!nm().isNotificationPolicyAccessGranted) {
                        handler.post { collapse(); openActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
                        return "!Izinkan akses Jangan Ganggu untuk X Arena dulu"
                    }
                    setDnd(!dndOn)
                    return if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati"
                }
                "eclipse" -> {
                    val v = !prefs.getBoolean("rb_eclipse", false)
                    prefs.edit().putBoolean("rb_eclipse", v).apply()
                    handler.post { if (v) showEclipse() else removeEclipse() }
                    return if (v) "Eclipse Touch aktif: sentuhan di tepi layar diblokir" else "Eclipse Touch mati"
                }
                "macro" -> return macroNext()
                "cxset" -> {
                    val i = arg.indexOf('=')
                    if (i > 0) {
                        val k = arg.substring(0, i); val v = arg.substring(i + 1)
                        val e = prefs.edit()
                        when (k) {
                            "shape", "size", "alpha" -> e.putInt("cx_$k", v.toIntOrNull() ?: 0)
                            "color" -> e.putString("cx_color", v)
                            "ms" -> e.putInt("tap_ms", v.toIntOrNull() ?: 100)
                        }
                        e.apply()
                        handler.post {
                            if (cross == null && k != "ms") showCross()
                            cross?.invalidate()
                        }
                    }
                    return ""
                }
                "bypass" -> return togglePref("rb_bypass", "Bypass Charging")
                "shot" -> {
                    handler.post { doShot() }
                    return ""
                }
                "rec" -> {
                    if (RecorderService.recording) {
                        startService(Intent(this@OverlayService, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
                        return "Rekaman dihentikan"
                    }
                    handler.post { collapse(); openActivity(Intent(this@OverlayService, CaptureActivity::class.java)) }
                    return ""
                }
                "wm" -> {
                    val willOn = mini == null
                    handler.post { toggleMini() }
                    return if (willOn) "Mini monitor aktif" else "Mini monitor mati"
                }
                "cross" -> {
                    val willOn = cross == null
                    handler.post { if (willOn) showCross() else removeCross() }
                    return if (willOn) "Crosshair aktif" else "Crosshair mati"
                }
                "wifi" -> {
                    if (wifiLock?.isHeld == true) {
                        try { wifiLock?.release() } catch (_: Exception) {}
                        wifiLock = null
                        return "Network speed boost mati"
                    }
                    return try {
                        val wm2 = applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                        @Suppress("DEPRECATION")
                        val mode = if (Build.VERSION.SDK_INT >= 29) android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY else android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
                        val l = wm2.createWifiLock(mode, "gameturbo:wifi")
                        l.setReferenceCounted(false)
                        l.acquire()
                        wifiLock = l
                        "Network speed boost aktif: Wi-Fi dijaga mode latensi rendah"
                    } catch (e: Exception) { "!Gagal mengaktifkan: " + (e.message ?: "") }
                }
                "autolight" -> {
                    if (!Settings.System.canWrite(this@OverlayService)) return "!Izinkan 'Ubah pengaturan sistem' dulu di X Arena"
                    val on = !Sys.autoLight(this@OverlayService)
                    Sys.setAutoLight(this@OverlayService, on)
                    return if (on) "Cahaya otomatis aktif" else "Cahaya otomatis mati"
                }
                "keep" -> {
                    val v = !prefs.getBoolean("keepmanual", false)
                    prefs.edit().putBoolean("keepmanual", v).apply()
                    keepOn = v || pmode == "gt"
                    handler.post { applyKeepOn() }
                    return if (v) "Layar tetap menyala" else "Layar boleh mati"
                }
                "cool" -> {
                    val on = !prefs.getBoolean("cool_on", false)
                    Thread { Sys.cooling(this@OverlayService, on) }.start()
                    return if (on) "Cooling aktif: app background ditutup, layar diredupkan" else "Cooling mati"
                }
                "bright" -> {
                    val pct = (arg.toIntOrNull() ?: 50).coerceIn(1, 100)
                    if (!Sys.setBright(this@OverlayService, pct)) return "!Izinkan 'Ubah pengaturan sistem' dulu"
                    return ""
                }
                "vol" -> {
                    Sys.setVol(this@OverlayService, (arg.toIntOrNull() ?: 50).coerceIn(0, 100))
                    return ""
                }
                "refresh" -> {
                    if (!Sys.setRefresh(this@OverlayService, arg == "high")) return "!Izinkan 'Ubah pengaturan sistem' dulu (atau HP tidak mendukung)"
                    return if (arg == "high") "Refresh rate tinggi diminta (tergantung HP)" else "Refresh rate standar"
                }
                "home" -> {
                    handler.post { collapse(); openActivity(Intent(this@OverlayService, MainActivity::class.java)) }
                    return ""
                }
                "xexit" -> {
                    prefs.edit().putBoolean("xmode", false).apply()
                    handler.post { collapse() }
                    return "Mode X ESPORT dimatikan"
                }
                "power" -> {
                    handler.post { collapse() }
                    return ""
                }
                "close" -> {
                    handler.post { collapse() }
                    return ""
                }
            }
            return ""
        }
    }

    companion object {
        const val ACTION_STOP = "com.gameturbo.app.STOP"
        const val ACTION_MINI = "com.gameturbo.app.MINI"
        const val ACTION_INTRO = "com.gameturbo.app.INTRO"
        const val EXTRA_GAME = "game"
        private const val NOTIF_ID = 2001

        @Volatile
        var running = false

        fun start(ctx: Context, gamePkg: String?) {
            val i = Intent(ctx, OverlayService::class.java)
            if (gamePkg != null) i.putExtra(EXTRA_GAME, gamePkg)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
